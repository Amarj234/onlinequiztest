import 'package:flutter/material.dart';

class allstudents extends StatefulWidget {
  const allstudents({Key? key}) : super(key: key);

  @override
  State<allstudents> createState() => _allstudentsState();
}

class _allstudentsState extends State<allstudents> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
