
class Serves{
//  String url ="http://192.168.0.131/dranchals/";

 String url ="http://gyandayinigirlsacademy.in/dranchals/api/";
}

